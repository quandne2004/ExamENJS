const express = require('express');
const userController = require('../controllers/UserController');
const router = express.Router();

router.get('/', (req, res) => {
    res.render('home');
});

router.get('/createUser', (req, res) => {
    res.render('createUser');  // Hiển thị view createUser.ejs
});

router.post('/createUser', userController.createUser);
router.get('/listuser', userController.getUsers);

module.exports = router;
