const db = require('../config/db');

exports.createUser = async (req, res) => {
    const { firstName, lastName, mobile, userName, password } = req.body;

    try {
        await db.execute(
            'INSERT INTO users (firstName, lastName, mobile, userName, password) VALUES (?, ?, ?, ?, ?)',
            [firstName, lastName, mobile, userName, password]
        );
        res.redirect('/listuser');
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating user' });
    }
};

exports.getUsers = async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM users');
        res.render('listuser', { users: rows });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching users' });
    }
};
